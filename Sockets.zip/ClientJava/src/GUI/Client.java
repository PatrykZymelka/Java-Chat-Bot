package GUI;

import java.io.*;
import java.net.Socket;
import java.util.Arrays;

public class Client {
    private Socket client;
    private BufferedReader reader;
    private BufferedWriter writer;

    public void Connect(int port) throws IOException {

        client = new Socket((String) null, port);
        InputStreamReader inputStreamReader = new InputStreamReader(client.getInputStream());
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(client.getOutputStream());
        reader = new BufferedReader(inputStreamReader);
        writer = new BufferedWriter(outputStreamWriter);
    }

    public void Send(String s) throws IOException {
        writer.write(s);
        writer.newLine();
        writer.flush();
        String Read = reader.readLine();
        read(Read);
    }

    public void close() throws IOException {
        reader.close();
        writer.close();
        client.close();
    }
    public void read(String Read) throws IOException{

        String[] parts = Read.split("-");
        String Operation = parts[0];
        String Sender = parts[1];
        String Receiver = parts[2];
        String Message = parts[3];
        String Port = parts[4];

        switch (Operation) {

            case "Refresh":
                String[] Users = Message.split(",");
                ClientCommandHandler.refresh(Users);
                break;

            case "Connect":
                ClientCommandHandler.connect(Sender, Port);
                break;

            case "SendM":
                break;

            case "GetM":
                String[] LM = Message.split(",");
                ClientCommandHandler.StoreM(Receiver,LM);
                break;


        }
    }
}