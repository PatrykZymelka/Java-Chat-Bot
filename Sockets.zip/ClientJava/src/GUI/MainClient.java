package GUI;

import java.io.IOException;

public class MainClient {
    public static void main(String[] args) throws IOException {
        MainWindow.getInstance();
    }

}
