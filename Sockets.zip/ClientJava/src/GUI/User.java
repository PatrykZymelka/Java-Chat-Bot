package GUI;
public class User {
    public static int Port;
    public static String Sender;
    public static String GetSender(){return Sender;}
    public static void SetSender(String S){Sender = S;}
    public static int GetPort(){return Port;}
    public static void SetPort(int P){Port = P;
    }


}
